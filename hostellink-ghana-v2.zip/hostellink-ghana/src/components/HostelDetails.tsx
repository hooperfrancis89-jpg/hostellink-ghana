import { useEffect, useRef } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import type { Hostel } from '../types'
import { TO_BE_CONFIRMED } from '../config'
import { mainAdmin } from '../data/agents'
import { formatPhone, telHref } from '../utils/phone'
import { adminWaUrl, bookingRequestMessage, enquiryMessage } from '../utils/whatsapp'
import HostelPhotoImg from './HostelPhotoImg'
import PhotoPlaceholder from './PhotoPlaceholder'
import PriceBlock from './PriceBlock'
import VerificationTag from './VerificationTag'
import { btnPrimary, btnSecondary, btnWhatsApp, Notice } from './ui'

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-1 border-b border-slate-100 py-3 sm:grid-cols-[200px_1fr]">
      <dt className="text-sm font-semibold text-slate-800">{label}</dt>
      <dd className="text-sm text-slate-700">{children}</dd>
    </div>
  )
}

export default function HostelDetails({ hostel: h }: { hostel: Hostel }) {
  const [params] = useSearchParams()
  const enquireRef = useRef<HTMLElement>(null)
  const official = h.category === 'official-university'

  useEffect(() => {
    if (params.get('enquire')) enquireRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }, [params])

  const unknown = <span className="font-medium text-amber-800">{TO_BE_CONFIRMED}</span>

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <Link to="/hostels" className="text-sm font-semibold text-brand-700 underline underline-offset-4">
        ← Back to all hostels
      </Link>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${official ? 'bg-purple-100 text-purple-900' : 'bg-brand-50 text-brand-700'}`}>
          {official ? 'Official university accommodation' : 'Private hostel'}
        </span>
        <VerificationTag status={h.verification} />
      </div>
      <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-brand-900">{h.name}</h1>
      <p className="mt-1 text-slate-700">
        {h.address ?? 'Exact address to be confirmed'} · {h.area} (search area)
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-3" aria-label="Photograph gallery">
        {h.photos.length > 0
          ? h.photos.map((p) => <HostelPhotoImg key={p.src} photo={p} className="overflow-hidden rounded-xl" />)
          : [<PhotoPlaceholder key="p" label="Photo unavailable" className="aspect-[16/10] w-full rounded-xl sm:col-span-3 sm:aspect-[3/1]" />]}
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div>
          <p className="text-slate-800">{h.description}</p>
          <dl className="mt-4">
            <Row label="Price and payment period">
              <PriceBlock hostel={h} large />
            </Row>
            <Row label="Room types">{h.roomTypes ? h.roomTypes.join(', ') : unknown}</Row>
            <Row label="Facilities">{h.facilities ? h.facilities.join(', ') : unknown}</Row>
            <Row label="Nearby landmarks">{h.nearbyLandmarks ? h.nearbyLandmarks.join(', ') : unknown}</Row>
            <Row label="Availability">{h.availability ?? unknown}</Row>
            <Row label="Sources">
              <ul className="list-disc space-y-1 pl-5">
                {h.sources.map((s) => (
                  <li key={s.url}>
                    <a href={s.url} target="_blank" rel="noopener noreferrer" className="text-brand-700 underline underline-offset-2">
                      {s.label}
                    </a>
                  </li>
                ))}
              </ul>
              <p className="mt-2 text-xs text-slate-600">
                Source links are research starting points. They do not prove current prices or availability.
              </p>
            </Row>
          </dl>
        </div>

        <aside ref={enquireRef} id="enquire" className="h-fit space-y-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" aria-labelledby="enq-title">
          <h2 id="enq-title" className="text-lg font-bold text-brand-900">
            Enquire or request a booking
          </h2>
          {official ? (
            <Notice tone="warn">
              This is official university accommodation. Apply through the university’s own hostel portal. HostelLink
              Ghana cannot book it for you.
            </Notice>
          ) : (
            <>
              <p className="text-sm text-slate-700">
                Your message opens in WhatsApp for you to review and send. Sending an enquiry or a booking request does{' '}
                <strong>not</strong> confirm a booking.
              </p>
              <a href={adminWaUrl(enquiryMessage(h.name, h.area))} target="_blank" rel="noopener noreferrer" className={`${btnWhatsApp} w-full`}>
                Send an Enquiry
              </a>
              <a href={adminWaUrl(bookingRequestMessage(h.name, h.area))} target="_blank" rel="noopener noreferrer" className={`${btnPrimary} w-full`}>
                Request a Booking
              </a>
            </>
          )}
          <div className="border-t border-slate-100 pt-4 text-sm">
            <p className="font-semibold text-slate-800">Contact</p>
            <p className="text-slate-700">
              {mainAdmin.name} — Main Admin ({formatPhone(mainAdmin.phoneLocal)})
            </p>
            <p className="mt-1 text-xs text-slate-600">
              No hostel-specific agent has been confirmed for this listing yet, so enquiries go to the main
              administrator.
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <a href={adminWaUrl(`Hello, I have a question about ${h.name}.`)} target="_blank" rel="noopener noreferrer" className={btnWhatsApp}>
                WhatsApp
              </a>
              <a href={telHref(mainAdmin.phoneLocal)} className={btnSecondary}>
                Call
              </a>
            </div>
            <Link to="/agents" className="mt-3 inline-block text-xs font-semibold text-brand-700 underline underline-offset-2">
              See the full team
            </Link>
          </div>
          <Link to="/safety" className="block text-xs font-semibold text-brand-700 underline underline-offset-2">
            Read the safety checklist before paying anyone
          </Link>
        </aside>
      </div>
    </div>
  )
}
